"""
Minimal self-checks for the Task 1.1 exercise files.
Run:  python test_all.py
Every assert below is a case I decided the code must handle, including
invalid input - not just the happy path.
"""
import importlib
import sys

sys.path.insert(0, ".")

m01 = importlib.import_module("01_variables_and_datatypes")
m02 = importlib.import_module("02_conditions_and_loops")
m03 = importlib.import_module("03_functions")
m04 = importlib.import_module("04_data_structures")
m05 = importlib.import_module("05_strings")
m07 = importlib.import_module("07_exception_handling")
m08 = importlib.import_module("08_oop")


def check(label: str, condition: bool) -> None:
    print(f"[{'PASS' if condition else 'FAIL':>4}] {label}")
    assert condition, label


check("numeric operators: 17 // 5 == 3", m01.numeric_operators(17, 5)["floor_division"] == 3)
check("grade 90 -> A+", m02.calculate_grade(90) == "A+")
check("grade 39 -> F", m02.calculate_grade(39) == "F")

try:
    m02.calculate_grade(-1)
    raised = False
except ValueError:
    raised = True
check("grade(-1) raises ValueError", raised)

check("17 is prime", m02.analyze_number(17)["is_prime"])
check("18 is not prime", not m02.analyze_number(18)["is_prime"])
check("mean of empty list is 0.0", m03.mean([]) == 0.0)
check("summarize rounds the mean", m03.summarize([1, 2, 2]) ["mean"] == 1.67)
check("topper is Chirag", m04.topper(m04.STUDENTS)["name"] == "Chirag")
check("messy labels collapse to one", len({m05.clean_label(x) for x in
      ["  MACHINE  learning ", "machine learning"]}) == 1)
check("mask_email hides the user", m05.mask_email("intern@x.com").startswith("in"))

good, bad = m07.process_batch(["88", "abc", "140"])
check("batch accepts 1 valid row", good == [88.0])
check("batch rejects 2 invalid rows", len(bad) == 2)

intern = m08.InternStudent("R1", "Test", {"a": 80, "b": 90}, "AI & ML")
intern.complete_task("1.1")
intern.complete_task("1.1")
check("duplicate task not counted twice", len(intern.completed_tasks) == 1)
check("intern inherits Student", isinstance(intern, m08.Student))
check("grade property works", intern.grade == "A")

print("\nAll checks passed.")
