"""
Topic 6 - File handling: write/read a text file and a CSV, and test a missing file.
Run:  python 06_file_handling.py
Files are written into ./_file_demo/ (git-ignored) so the repository stays clean
and the demo is fully reproducible.
"""
import csv
import os

DEMO_DIR = "_file_demo"
TEXT_FILE = os.path.join(DEMO_DIR, "notes.txt")
CSV_FILE = os.path.join(DEMO_DIR, "marks.csv")

ROWS = [
    {"roll": "AIML-01", "name": "Aarav", "marks": 88},
    {"roll": "AIML-02", "name": "Bhavna", "marks": 74},
    {"roll": "AIML-03", "name": "Chirag", "marks": 91},
]


def write_text(path: str, lines: list) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def read_text(path: str) -> list:
    with open(path, "r", encoding="utf-8") as f:
        return [line.rstrip("\n") for line in f]


def write_csv(path: str, rows: list) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def read_csv(path: str) -> list:
    with open(path, "r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def safe_read(path: str) -> list:
    """Edge case the guide asks for: reading a file that does not exist."""
    try:
        return read_text(path)
    except FileNotFoundError:
        print(f"handled: '{path}' does not exist - returning empty list")
        return []


def main() -> None:
    os.makedirs(DEMO_DIR, exist_ok=True)

    write_text(TEXT_FILE, ["week 1 - python fundamentals", "file handling practice"])
    print("text file contents:", read_text(TEXT_FILE))

    write_csv(CSV_FILE, ROWS)
    loaded = read_csv(CSV_FILE)
    print("csv rows read back:", len(loaded))
    # NOTE: csv gives back strings - casting is my responsibility.
    total = sum(int(row["marks"]) for row in loaded)
    print("average marks:", round(total / len(loaded), 2))

    print("\n--- missing file test ---")
    safe_read(os.path.join(DEMO_DIR, "does_not_exist.txt"))


if __name__ == "__main__":
    main()
