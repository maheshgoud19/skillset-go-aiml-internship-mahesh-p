"""
Topic 4 - Lists, tuples, sets, dictionaries used on one realistic mini problem:
a small student-records system.
Run:  python 04_data_structures.py
"""

STUDENTS = [
    {"roll": "AIML-01", "name": "Aarav",  "marks": {"math": 88, "python": 92, "ml": 79}},
    {"roll": "AIML-02", "name": "Bhavna", "marks": {"math": 74, "python": 68, "ml": 85}},
    {"roll": "AIML-03", "name": "Chirag", "marks": {"math": 91, "python": 95, "ml": 90}},
    {"roll": "AIML-04", "name": "Divya",  "marks": {"math": 59, "python": 71, "ml": 64}},
]

# A tuple is used here on purpose: the subject list must not change at runtime.
SUBJECTS = ("math", "python", "ml")


def average(marks: dict) -> float:
    return sum(marks.values()) / len(marks)


def topper(students: list) -> dict:
    """max() with a key function - no manual loop needed."""
    return max(students, key=lambda s: average(s["marks"]))


def subject_average(students: list, subject: str) -> float:
    return sum(s["marks"][subject] for s in students) / len(students)


def students_above(students: list, cutoff: float) -> list:
    """List comprehension with a filter."""
    return [s["name"] for s in students if average(s["marks"]) >= cutoff]


def unique_grades(students: list) -> set:
    """A set removes duplicates automatically."""
    grades = set()
    for s in students:
        avg = average(s["marks"])
        grades.add("A" if avg >= 85 else "B" if avg >= 70 else "C")
    return grades


def ranked(students: list) -> list:
    """sorted() returns a NEW list; the original order is preserved."""
    return sorted(students, key=lambda s: average(s["marks"]), reverse=True)


def main() -> None:
    print("--- per student ---")
    for s in STUDENTS:
        print(f"{s['roll']} {s['name']:<8} avg={average(s['marks']):.2f}")

    print("\n--- per subject ---")
    for subject in SUBJECTS:
        print(f"{subject:<8} avg={subject_average(STUDENTS, subject):.2f}")

    print("\ntopper:", topper(STUDENTS)["name"])
    print("above 80:", students_above(STUDENTS, 80))
    print("grades present:", sorted(unique_grades(STUDENTS)))
    print("rank order:", [s["name"] for s in ranked(STUDENTS)])

    print("\n--- tuples are immutable ---")
    try:
        SUBJECTS[0] = "statistics"
    except TypeError as exc:
        print("handled:", exc)


if __name__ == "__main__":
    main()
