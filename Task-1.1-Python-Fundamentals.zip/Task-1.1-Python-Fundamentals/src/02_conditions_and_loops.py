"""
Topic 2 - Conditions and loops through small utilities.
Run:  python 02_conditions_and_loops.py
Utilities included: grade calculator, number analyzer, pattern generator.
"""


def calculate_grade(marks: float) -> str:
    """Map marks (0-100) to a grade. Raises ValueError on impossible input."""
    if not 0 <= marks <= 100:
        raise ValueError(f"marks must be between 0 and 100, got {marks}")
    if marks >= 90:
        return "A+"
    elif marks >= 80:
        return "A"
    elif marks >= 70:
        return "B"
    elif marks >= 60:
        return "C"
    elif marks >= 40:
        return "D"
    return "F"


def analyze_number(n: int) -> dict:
    """Classify one integer - uses a loop for the divisor search."""
    divisors = [d for d in range(1, n + 1) if n % d == 0] if n > 0 else []
    return {
        "number": n,
        "sign": "positive" if n > 0 else "negative" if n < 0 else "zero",
        "parity": "even" if n % 2 == 0 else "odd",
        "divisors": divisors,
        "is_prime": len(divisors) == 2,
    }


def triangle_pattern(rows: int) -> str:
    """Nested loops: build a right-angled star pattern as one string."""
    lines = []
    for i in range(1, rows + 1):
        lines.append("*" * i)
    return "\n".join(lines)


def collatz_steps(n: int, max_steps: int = 1000) -> int:
    """while-loop practice: how many steps until the sequence reaches 1."""
    steps = 0
    while n != 1 and steps < max_steps:
        n = n // 2 if n % 2 == 0 else 3 * n + 1
        steps += 1
    return steps


def main() -> None:
    print("--- grade calculator ---")
    for marks in (95, 84, 72, 61, 45, 12):
        print(f"{marks:>3} -> {calculate_grade(marks)}")

    print("\n--- edge case: invalid marks ---")
    try:
        calculate_grade(140)
    except ValueError as exc:
        print("handled:", exc)

    print("\n--- number analyzer ---")
    for n in (17, 18, -4, 0):
        info = analyze_number(n)
        print(f"{n:>3}: {info['sign']}, {info['parity']}, prime={info['is_prime']}")

    print("\n--- pattern generator ---")
    print(triangle_pattern(5))

    print("\n--- while loop (Collatz steps) ---")
    for n in (6, 7, 27):
        print(f"{n:>3} -> {collatz_steps(n)} steps")


if __name__ == "__main__":
    main()
