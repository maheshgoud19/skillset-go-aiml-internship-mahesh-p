"""
Topic 7 - Exception handling done narrowly, not with a blanket 'except:'.
Run:  python 07_exception_handling.py
"""


class InvalidMarksError(ValueError):
    """Custom exception: marks outside 0-100."""


def parse_marks(raw: str) -> float:
    """Convert user input to marks, raising a precise error for each failure."""
    try:
        value = float(raw)
    except ValueError:
        # Re-raised with context so the caller knows WHAT failed, not just that it did.
        raise InvalidMarksError(f"'{raw}' is not a number") from None
    if not 0 <= value <= 100:
        raise InvalidMarksError(f"{value} is outside 0-100")
    return value


def safe_divide(a: float, b: float) -> float:
    try:
        return a / b
    except ZeroDivisionError:
        print("handled: division by zero -> returning infinity placeholder")
        return float("inf")


def read_config(data: dict, key: str, default=None):
    try:
        return data[key]
    except KeyError:
        print(f"handled: missing key '{key}' -> using default {default!r}")
        return default


def process_batch(raw_inputs: list) -> tuple:
    """try/except/else/finally on a realistic batch - bad rows are reported, not hidden."""
    good, bad = [], []
    try:
        for raw in raw_inputs:
            try:
                marks = parse_marks(raw)
            except InvalidMarksError as exc:
                bad.append((raw, str(exc)))
            else:
                good.append(marks)
    finally:
        print(f"batch finished: {len(raw_inputs)} rows attempted")
    return good, bad


def main() -> None:
    good, bad = process_batch(["88", "74.5", "abc", "140", "-3", "100"])
    print("accepted:", good)
    print("rejected:")
    for raw, reason in bad:
        print(f"   {raw!r:>6} -> {reason}")

    print("\nsafe_divide(10, 0):", safe_divide(10, 0))
    print(read_config({"epochs": 10}, "learning_rate", default=0.01))


if __name__ == "__main__":
    main()
