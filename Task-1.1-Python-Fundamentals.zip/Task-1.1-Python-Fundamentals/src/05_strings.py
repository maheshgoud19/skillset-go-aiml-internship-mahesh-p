"""
Topic 5 - String handling: slicing, methods, formatting, simple text cleaning.
This one is directly useful in Task 1.2 (cleaning messy category text).
Run:  python 05_strings.py
"""


def clean_label(raw: str) -> str:
    """Normalise a messy category label the way I will need to in EDA."""
    return " ".join(raw.strip().lower().split()).title()


def is_palindrome(text: str) -> bool:
    letters = [ch.lower() for ch in text if ch.isalnum()]
    return letters == letters[::-1]


def word_frequency(text: str) -> dict:
    """Count words after stripping punctuation - a tiny bag-of-words."""
    cleaned = "".join(ch.lower() if ch.isalnum() or ch.isspace() else " " for ch in text)
    counts: dict = {}
    for word in cleaned.split():
        counts[word] = counts.get(word, 0) + 1
    return dict(sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])))


def mask_email(email: str) -> str:
    """Slicing practice with a privacy-minded example."""
    if "@" not in email:
        return "invalid email"
    user, domain = email.split("@", 1)
    visible = user[:2] if len(user) > 2 else user
    return f"{visible}{'*' * max(len(user) - 2, 0)}@{domain}"


def main() -> None:
    messy = ["  MACHINE  learning ", "machine learning", "Machine Learning  "]
    print("--- label cleaning ---")
    for raw in messy:
        print(f"{raw!r:<28} -> {clean_label(raw)!r}")
    print("distinct after cleaning:", len({clean_label(m) for m in messy}))

    print("\n--- palindrome ---")
    for text in ("Never odd or even", "machine learning"):
        print(f"{text!r} -> {is_palindrome(text)}")

    print("\n--- word frequency ---")
    sample = "Data is messy. Data needs cleaning, and clean data trains better models."
    for word, count in list(word_frequency(sample).items())[:5]:
        print(f"{word:<10}{count}")

    print("\n--- slicing ---")
    print(mask_email("intern.aiml@example.com"))
    print(mask_email("not-an-email"))


if __name__ == "__main__":
    main()
