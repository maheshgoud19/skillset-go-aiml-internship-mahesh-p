"""
Topic 3 - Functions: parameters, defaults, *args/**kwargs, return values, scope.
Run:  python 03_functions.py
"""


def mean(values: list) -> float:
    """Average of a list. Returns 0.0 for an empty list instead of crashing."""
    return sum(values) / len(values) if values else 0.0


def summarize(values: list, ndigits: int = 2) -> dict:
    """Default argument in action: caller can change rounding, or ignore it."""
    if not values:
        return {"count": 0, "mean": 0.0, "minimum": None, "maximum": None}
    return {
        "count": len(values),
        "mean": round(mean(values), ndigits),
        "minimum": min(values),
        "maximum": max(values),
    }


def total_marks(*subject_marks: float) -> float:
    """*args: any number of subjects."""
    return sum(subject_marks)


def build_profile(name: str, **details) -> dict:
    """**kwargs: optional named details collected into a dict."""
    profile = {"name": name}
    profile.update(details)
    return profile


COUNTER = 0


def increment() -> int:
    """Scope demo: 'global' is needed to rebind a module-level name."""
    global COUNTER
    COUNTER += 1
    return COUNTER


def apply_twice(func, value):
    """Functions are objects - they can be passed as arguments."""
    return func(func(value))


def main() -> None:
    marks = [88, 74, 91, 63, 79]
    print("summary:", summarize(marks))
    print("empty list is handled:", summarize([]))
    print("total marks:", total_marks(88, 74, 91))
    print("profile:", build_profile("Intern", domain="AI/ML", year=3))
    print("counter:", increment(), increment(), increment())
    print("apply_twice(square, 3):", apply_twice(lambda x: x * x, 3))


if __name__ == "__main__":
    main()
