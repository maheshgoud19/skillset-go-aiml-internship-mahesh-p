"""
Topic 8 - OOP: classes, attributes, methods, inheritance, dunder methods.
Run:  python 08_oop.py

WHY A CLASS HERE: a dataset record has data (rows) AND behaviour (summary,
validation) that always belong together. Passing a bare list of dicts around
means every caller re-implements the same checks. A class keeps the state and
the rules in one place - the same reason sklearn wraps models in objects.
"""


class Student:
    """One student record."""

    def __init__(self, roll: str, name: str, marks: dict):
        self.roll = roll
        self.name = name
        self.marks = marks

    @property
    def average(self) -> float:
        return sum(self.marks.values()) / len(self.marks) if self.marks else 0.0

    @property
    def grade(self) -> str:
        avg = self.average
        return "A" if avg >= 85 else "B" if avg >= 70 else "C" if avg >= 50 else "F"

    def __repr__(self) -> str:
        return f"Student({self.roll!r}, {self.name!r}, avg={self.average:.1f})"


class InternStudent(Student):
    """Inheritance: an intern is a student with extra internship state."""

    def __init__(self, roll: str, name: str, marks: dict, domain: str):
        super().__init__(roll, name, marks)
        self.domain = domain
        self.completed_tasks: list = []

    def complete_task(self, task_id: str) -> None:
        if task_id not in self.completed_tasks:
            self.completed_tasks.append(task_id)

    def progress(self, total_tasks: int = 16) -> str:
        pct = len(self.completed_tasks) / total_tasks * 100
        return f"{len(self.completed_tasks)}/{total_tasks} tasks ({pct:.0f}%)"

    def __repr__(self) -> str:  # method overriding
        return f"InternStudent({self.name!r}, domain={self.domain!r}, {self.progress()})"


class Classroom:
    """Container class showing __len__, __iter__ and aggregation."""

    def __init__(self, title: str):
        self.title = title
        self._students: list = []

    def add(self, student: Student) -> "Classroom":
        if not isinstance(student, Student):
            raise TypeError("only Student objects can be added")
        self._students.append(student)
        return self  # allows chaining

    def __len__(self) -> int:
        return len(self._students)

    def __iter__(self):
        return iter(self._students)

    def class_average(self) -> float:
        return sum(s.average for s in self) / len(self) if len(self) else 0.0


def main() -> None:
    room = Classroom("AI/ML - Year 3")
    room.add(Student("AIML-01", "Aarav", {"math": 88, "python": 92}))
    room.add(Student("AIML-02", "Bhavna", {"math": 74, "python": 68}))

    intern = InternStudent("AIML-03", "Chirag", {"math": 91, "python": 95}, "AI & ML")
    for task in ("1.1", "1.2", "1.3"):
        intern.complete_task(task)
    intern.complete_task("1.1")  # duplicate is ignored
    room.add(intern)

    print("--- students ---")
    for student in room:
        print(" ", student, "grade:", student.grade)

    print("\nclass size:", len(room))
    print("class average:", round(room.class_average(), 2))
    print("intern progress:", intern.progress())
    print("inheritance check - isinstance(intern, Student):", isinstance(intern, Student))

    print("\n--- edge case: wrong type ---")
    try:
        room.add("not a student")
    except TypeError as exc:
        print("handled:", exc)


if __name__ == "__main__":
    main()
