"""
Topic 1 - Variables, data types, operators and I/O.
Run:  python 01_variables_and_datatypes.py
Why this exists: these are the containers every later program uses. Before
touching ML I want to be sure I know what type I am holding and what an
operation does to it.
"""


def describe(value):
    """Return a readable 'value -> type' description of any object."""
    return f"{value!r:>20}  ->  {type(value).__name__}"


def numeric_operators(a: float, b: float) -> dict:
    """Demonstrate the operators I actually use later (// and % show up in batching)."""
    return {
        "sum": a + b,
        "difference": a - b,
        "product": a * b,
        "true_division": a / b,
        "floor_division": a // b,
        "remainder": a % b,
        "power": a ** 2,
    }


def temperature_report(celsius: float) -> str:
    """Small realistic use of f-strings and formatting."""
    fahrenheit = celsius * 9 / 5 + 32
    return f"{celsius:.1f} C = {fahrenheit:.1f} F"


def main() -> None:
    samples = [42, 3.14, "AI/ML", True, None, [1, 2], (1, 2), {1, 2}, {"a": 1}]
    print("--- data types ---")
    for item in samples:
        print(describe(item))

    print("\n--- operators (a=17, b=5) ---")
    for name, result in numeric_operators(17, 5).items():
        print(f"{name:>16}: {result}")

    print("\n--- type casting ---")
    text_number = "250"
    print(describe(text_number), "-> after int():", describe(int(text_number)))

    print("\n--- formatted output ---")
    for c in (-10, 0, 36.6):
        print(temperature_report(c))


if __name__ == "__main__":
    main()
