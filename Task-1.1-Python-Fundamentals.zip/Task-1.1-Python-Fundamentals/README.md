# Task 1.1 - Python Fundamentals Assignment

**Level:** Beginner | **Week:** 1 | **Domain:** AI & Machine Learning

## Objective
Build practical command of core Python - variables, data types, operators, conditions,
loops, functions, lists/tuples/sets/dictionaries, strings, file handling, exception
handling and OOP - by solving a small problem with each feature rather than memorising
syntax.

## Tools Used
- Python 3.10+ (standard library only - no external packages needed)
- `csv` and `os` from the standard library
- VS Code / Jupyter for editing

## Work Completed
| File | Topic | What it demonstrates |
|---|---|---|
| `src/01_variables_and_datatypes.py` | variables, types, operators, I/O | type inspection, all arithmetic operators, casting, f-string formatting |
| `src/02_conditions_and_loops.py` | conditions, for/while loops | grade calculator, number analyzer, pattern generator, Collatz step counter |
| `src/03_functions.py` | functions | defaults, `*args`, `**kwargs`, scope, functions passed as arguments |
| `src/04_data_structures.py` | list/tuple/set/dict | student-records mini system, comprehensions, `sorted` with a key |
| `src/05_strings.py` | strings | label normalisation, palindrome check, word frequency, slicing |
| `src/06_file_handling.py` | file I/O | write/read a text file and a CSV, missing-file edge case |
| `src/07_exception_handling.py` | exceptions | custom exception class, narrow `except` blocks, batch validation |
| `src/08_oop.py` | OOP | class, properties, inheritance, method overriding, `__len__`/`__iter__` |
| `src/test_all.py` | verification | 16 assertions including invalid-input cases |

## How to Run
```bash
cd Week-1/Task-1.1-Python-Fundamentals/src
python 01_variables_and_datatypes.py     # or any other file
python test_all.py                       # runs all self-checks
```
Each file is independent and prints its own output. `06_file_handling.py` creates a
git-ignored `_file_demo/` folder.

## Deliverables
- 8 topic files organised by subject (not one large file)
- `test_all.py` self-check suite - all 16 checks pass
- This README with run instructions
- `screenshots/` - terminal output of each script

## Key Learnings
1. A broad `except:` hides real bugs. Catching `ValueError`, `ZeroDivisionError`,
   `KeyError` and `FileNotFoundError` separately meant each failure could be reported
   with a useful message instead of being swallowed.
2. Defining a custom exception (`InvalidMarksError`) made the batch validator far
   clearer than returning `None` or `-1` for bad rows.
3. A class is worth it when data and the rules about that data always travel together -
   the same reason scikit-learn wraps models in objects rather than passing arrays around.
4. `csv.DictReader` returns strings; casting is the programmer's job. This is the exact
   failure mode that shows up again as an object-dtype column in Task 1.2.
5. Writing the assertion *before* fixing the code made the invalid-input paths get tested
   instead of assumed.

## Submission Status
**Status:** Completed
**Submitted On:** _<fill in>_
