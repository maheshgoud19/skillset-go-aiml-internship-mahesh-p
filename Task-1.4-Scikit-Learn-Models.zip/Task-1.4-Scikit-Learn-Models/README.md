# Task 1.4 - Two ML Models with Scikit-learn

**Level:** Intermediate | **Week:** 1 | **Domain:** AI & Machine Learning

## Objective
Build one **regression** model and one **classification** model end to end - problem
definition, split, preprocessing pipeline, baseline, training, metric selection, error
inspection and documented limitations - in a single notebook with both workflows clearly
labelled.

## Tools Used
Python · scikit-learn · Pandas · NumPy · Matplotlib · joblib · Jupyter Notebook

## The two workflows
| | **Workflow A - Regression** | **Workflow B - Classification** |
|---|---|---|
| dataset | UCI Diabetes, 442 patients × 10 features (`load_diabetes`) | cleaned wine data from **Task 1.2**, 178 × 13 |
| target | disease progression after 1 year (continuous) | cultivar A / B / C (3 classes) |
| baseline | `DummyRegressor(mean)` - MAE 64.0 | `DummyClassifier(most_frequent)` - accuracy 0.389 |
| models | Linear Regression, Ridge, Random Forest | Logistic Regression, Random Forest |
| metrics | MAE, RMSE, R², 5-fold CV | accuracy, macro precision/recall/F1, confusion matrix, stratified 5-fold CV |
| selected | **Ridge (α=1.0)** - R² 0.454, MAE 42.8 | **Random Forest** - CV macro F1 0.986 |

## Work Completed
1. Defined both problems and stated why each needs different metrics
2. **Split before preprocessing** in both workflows so no test statistics leak in
3. Put `StandardScaler` inside a `Pipeline` so the same transform is applied at inference
4. Trained a **dummy baseline first** in each workflow - the reference every later number is judged against
5. Trained 3 regressors and 2 classifiers, each cross-validated on the training set
6. Explained the choice of every metric rather than reporting a single score
7. Inspected the errors: residual plots, the 8 worst predictions, residuals split by target
   level, confusion matrix, feature importances
8. Saved both pipelines with joblib and verified that a reloaded pipeline reproduces the
   predictions exactly
9. Wrote `results/evaluation_report.md` with assumptions and limitations

## How to Run
```bash
pip install -r ../../requirements.txt
# Task 1.2 must be run first - Workflow B uses its cleaned dataset
cd Week-1/Task-1.2-Data-Cleaning-EDA && python make_raw_dataset.py && python eda_pipeline.py
cd ../Task-1.4-Scikit-Learn-Models && jupyter notebook notebook.ipynb   # or: python ml_models.py
```

## Deliverables
- `notebook.ipynb` - both workflows plus the evaluation section (39 cells)
- `ml_models.py` - the same code as a script
- **`results/evaluation_report.md`** - the evaluation report deliverable
- `results/metrics.json`, `regression_metrics.csv`, `classification_metrics.csv`
- `results/A_regression_diagnostics.png`, `B_confusion_matrix.png`, `B_feature_importance.png`
- `models/regression_pipeline.joblib`, `models/classification_pipeline.joblib`
- `results/run_output.txt` - captured console output of a full run

## Headline results
**Regression:** Ridge cuts MAE from the baseline's 64.0 to **42.8** and reaches **R² 0.454**.
The 11-point gap between RMSE (53.8) and MAE shows a heavy error tail, and residuals split
by target level (**+35.6** high half, **−27.0** low half) show the model regressing toward
the mean - it misses exactly the severe cases that matter most.

**Classification:** both models score 1.000 on the 36-sample test set, so the honest number
is the cross-validated macro F1: **0.978** (logistic regression) and **0.986** (random
forest). The top three features - `proline_mg_l`, `flavanoids`, `color_intensity` - are
precisely the three that Task 1.2's EDA predicted would separate the cultivars.

## Key Learnings
1. A baseline is what turns a metric into evidence. "R² = 0.45" means nothing until the
   mean-predictor's R² ≈ 0 is sitting next to it.
2. The Pipeline is not tidiness - it is what stops scaling statistics computed on the whole
   dataset from leaking test information into training.
3. More capacity is not better: the random forest lost to Ridge on 354 rows *and* had
   triple the cross-validation variance.
4. A perfect test score is a warning, not a trophy. On 36 samples it is one mistake away
   from 97%, which is why the CV score is what I report.
5. Removing duplicates back in Task 1.2 was load-bearing here - identical rows split across
   train and test would have leaked and inflated the classification score.
6. Errors are not uniform. Mean residual ≈ 0 looked unbiased until I split by target level
   and found a systematic pattern underneath.

## Limitations
- Regression explains under half the variance and cannot be used for individual decisions.
- 36 test samples is small; cross-validated scores are the stable ones.
- No hyperparameter tuning - deliberately, since the roadmap places controlled
  experimentation in Week 2 (Task 2.3) and tuning before a baseline is the mistake the
  execution guide warns about.

## Submission Status
**Status:** Completed
**Submitted On:** _<fill in>_
