# Task 1.2 - Data Cleaning & EDA

**Level:** Beginner | **Week:** 1 | **Domain:** AI & Machine Learning

## Objective
Clean a messy real-world dataset using NumPy, Pandas and Matplotlib, justify every
cleaning decision in writing, and explore the data to answer a stated question:
*which chemical measurements separate the three wine cultivars?*

## Dataset - read this before reviewing
**Source:** UCI Wine Recognition dataset - 178 real chemical analyses of wines grown in
the same region of Italy from three different cultivars. Loaded offline through
`sklearn.datasets.load_wine()`.

**Important and fully disclosed:** the scikit-learn copy is already tidy, so
`make_raw_dataset.py` re-exports it as a realistic *raw* file by adding the data-quality
problems that genuinely occur in system exports - missing cells, duplicate rows,
inconsistent category spelling, a numeric column stored as text with units, mixed date
formats, and chemically impossible values. **No measurement is invented; only the
formatting damage is, and it is reproducible with `random_state=42`.** Every cleaning step
in the notebook is therefore a step I can defend and explain.

## Tools Used
Python · Pandas · NumPy · Matplotlib · Jupyter Notebook · scikit-learn (dataset loader only)

## Work Completed
1. Generated the raw export (`make_raw_dataset.py`) - 184 rows × 16 columns
2. Inspected shape, dtypes, summary statistics, missing counts, duplicates and category counts
3. Dropped 6 exact duplicate rows (184 → 178)
4. Converted `proline` from text (`"1,065 mg/L"`) to numeric, renamed to `proline_mg_l`
5. Normalised 12 messy `cultivar` label spellings back to the 3 real categories
6. Parsed two different date formats into one datetime column
7. Converted 5 chemically impossible values (negative magnesium, zero ash) to NaN -
   cell-level errors, so the rest of each row was kept
8. Imputed missing values with the **median of the same cultivar**, per column, with the
   reason recorded for each; flagged affected rows with `was_imputed`
9. Flagged outliers with the IQR rule but **kept** them - plausible chemistry, not errors
10. Answered 6 EDA questions with charts, each followed by a written interpretation
11. Saved the cleaned dataset to a **new** file; the raw file is never overwritten

## How to Run
```bash
cd Week-1/Task-1.2-Data-Cleaning-EDA
python make_raw_dataset.py     # writes dataset/wine_quality_raw.csv
jupyter notebook notebook.ipynb
# or, non-interactively:
python eda_pipeline.py         # same code, script form
```

## Deliverables
- `notebook.ipynb` - the full cleaning + EDA story (47 cells)
- `eda_pipeline.py` - identical code as a runnable script
- `make_raw_dataset.py` - reproducible raw-data generator, fully documented
- `dataset/wine_quality_raw.csv` (184×16) and `dataset/wine_quality_cleaned.csv` (178×17)
- `visualizations/` - 6 charts, each answering a stated question
- `eda_run_output.txt` - captured console output of a full run

## Findings
1. The raw export had 6 duplicates, 12 spellings for 3 categories, a numeric column
   stored as text, mixed dates and 5 impossible values - **none of which raise an error**,
   all of which would have quietly corrupted a model.
2. `flavanoids`, `proline_mg_l` and `color_intensity` separate the three cultivars almost
   completely. *(Task 1.4 later confirmed these as the top 3 features by importance.)*
3. `total_phenols`, `flavanoids` and `od280_od315` correlate strongly (r ≈ 0.86) -
   overlapping phenolic chemistry, so they are near-duplicate signals, not independent evidence.
4. `magnesium`, `malic_acid` and `color_intensity` are right-skewed (skew 1.25 / 1.04 /
   0.87) - the concrete reason median, not mean, was used for imputation.
5. No trend across batch dates, so that column is not a hidden confound.

## Key Learnings
1. Missing values do not have one correct treatment. Cultivar-wise median preserved the
   between-group differences that a global fill would have flattened - and those
   differences were the entire point of the analysis.
2. An impossible value is a *cell* problem; deleting the whole row throws away 12 valid
   measurements to fix 1 bad one.
3. The IQR rule finds extremes, it does not identify errors. Domain meaning decides.
4. A chart without a question is decoration. Writing the question first changed which
   charts I made.
5. Correlation of 0.86 between phenolic measures reflects shared grape chemistry, not
   causation between the two columns.

## Limitations
- 178 samples is small; the Cultivar C median rests on only ~48 rows.
- Imputation slightly reduces the true variance of `alcohol`, `magnesium`, `hue` and `ash`.
- The data-quality problems are my documented simulation of a real export, not errors
  found in the wild.

## Submission Status
**Status:** Completed
**Submitted On:** _<fill in>_
