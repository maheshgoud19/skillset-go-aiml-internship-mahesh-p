"""
Build the RAW dataset used by this task.

SOURCE: the UCI Wine Recognition dataset shipped with scikit-learn
(178 real chemical analyses of wines from three cultivars in the same
region of Italy). It is loaded offline via sklearn.datasets.load_wine().

WHY A GENERATOR SCRIPT: the sklearn copy is already tidy. A real export
from a lab/LIMS system is not. This script writes a realistic "raw export"
by adding the data-quality problems that actually occur in exports:
missing cells, duplicated rows, inconsistent category spelling/whitespace,
a numeric column stored as text, impossible values, and a date column in
mixed formats. Nothing about the underlying measurements is invented -
only the formatting damage is, and it is documented here and in the README
so the cleaning work can be honestly defended.

Run:  python make_raw_dataset.py
Out:  dataset/wine_quality_raw.csv
"""
import os
import numpy as np
import pandas as pd
from sklearn.datasets import load_wine

RNG = np.random.default_rng(42)
OUT = os.path.join("dataset", "wine_quality_raw.csv")


def main() -> None:
    bunch = load_wine(as_frame=True)
    df = bunch.frame.copy()
    df.columns = [c.replace("/", "_") for c in df.columns]

    # Readable cultivar labels instead of 0/1/2
    names = {0: "Cultivar A", 1: "Cultivar B", 2: "Cultivar C"}
    df["cultivar"] = df.pop("target").map(names)
    df.insert(0, "sample_id", [f"W-{i:03d}" for i in range(1, len(df) + 1)])

    # A batch date column, stored in two different string formats (as exports do)
    base = pd.Timestamp("2026-01-05")
    dates = [base + pd.Timedelta(days=int(d)) for d in RNG.integers(0, 240, len(df))]
    df["batch_date"] = [
        d.strftime("%Y-%m-%d") if i % 3 else d.strftime("%d/%m/%Y")
        for i, d in enumerate(dates)
    ]

    # 1. inconsistent category text: case, stray spaces, abbreviations
    variants = {"Cultivar A": ["Cultivar A", "cultivar a", " CULTIVAR A ", "Cult. A"],
                "Cultivar B": ["Cultivar B", "cultivar  b", "CULTIVAR B", "Cult. B"],
                "Cultivar C": ["Cultivar C", " cultivar c", "Cultivar  C ", "Cult. C"]}
    df["cultivar"] = [RNG.choice(variants[v]) for v in df["cultivar"]]

    # 2. a genuinely numeric column exported as text with units and commas
    df["proline"] = [f"{v:,.0f} mg/L" for v in df["proline"]]

    # 3. missing values in three columns (MCAR, ~6-9% each)
    for col, frac in [("magnesium", 0.08), ("hue", 0.06), ("alcohol", 0.04)]:
        idx = RNG.choice(df.index, size=int(len(df) * frac), replace=False)
        df.loc[idx, col] = np.nan

    # 4. impossible values that must be caught, not silently averaged
    df.loc[RNG.choice(df.index, 3, replace=False), "magnesium"] = -1
    df.loc[RNG.choice(df.index, 2, replace=False), "ash"] = 0

    # 5. exact duplicate rows appended at the end (re-export artefact)
    dupes = df.sample(6, random_state=7)
    df = pd.concat([df, dupes], ignore_index=True)

    # 6. shuffle so the duplicates are not conveniently at the bottom
    df = df.sample(frac=1, random_state=11).reset_index(drop=True)

    os.makedirs("dataset", exist_ok=True)
    df.to_csv(OUT, index=False)
    print(f"wrote {OUT}  shape={df.shape}")
    print("injected issues: missing values, 6 duplicate rows, messy category text,")
    print("proline stored as text, negative magnesium, zero ash, mixed date formats")


if __name__ == "__main__":
    main()
