# Task 1.3 - Math for ML Practice Set

**Level:** Beginner | **Week:** 1 | **Domain:** AI & Machine Learning

## Objective
Work through the mathematics that ML actually uses - descriptive statistics, probability,
linear algebra and basic calculus - solving each problem **with the steps shown**, then
verifying the result numerically, and connecting each idea to where it appears inside an
ML algorithm.

## Tools Used
Python · NumPy · Jupyter Notebook · LaTeX (markdown maths)

## Work Completed
| Section | Problems solved by hand |
|---|---|
| 1. Descriptive statistics | mean, median, population vs sample variance, standard deviation (with the full deviation table); covariance and correlation from first principles |
| 2. Probability | conditional probability from a confusion table (precision vs recall are different conditionals); Bayes' theorem on a rare-disease test; expected value and a break-even accuracy |
| 3. Linear algebra | dot product, magnitudes and the angle between vectors; matrix multiplication computed entry by entry with a dimension check; one linear layer `Wx + b` followed by ReLU, by hand |
| 4. Calculus | differentiation term by term, evaluating the derivative as a rate of change, locating a minimum; **gradient descent stepped through by hand** for 3 iterations, then run at three learning rates |

Every hand answer is checked against NumPy in the cell below it, and every problem ends
with a one-line "ML link".

## How to Run
```bash
cd Week-1/Task-1.3-Math-for-ML
jupyter notebook math_for_ml_solutions.ipynb
# or, non-interactively:
python math_for_ml.py
```
To produce the PDF deliverable: **File → Download as → PDF**, or
`jupyter nbconvert --to pdf math_for_ml_solutions.ipynb`.

## Deliverables
- `math_for_ml_solutions.ipynb` - worked solutions with steps, LaTeX and verification code
- `math_for_ml.py` - the same content as a runnable script
- `solutions/verification_output.txt` - console output confirming every hand-computed answer
- Export the notebook to PDF if the Google Form asks for a PDF

## Selected results (hand-computed, NumPy-verified)
| Problem | Answer |
|---|---|
| variance of the 8 marks | 127.75 (population) / 146.0 (sample) |
| correlation of hours vs marks | r ≈ 0.996 |
| precision / recall from the confusion table | 0.846 / 0.917 |
| Bayes - P(sick given a positive test) | **0.167** |
| break-even accuracy for the payoff problem | ≈ 0.714 |
| a · b, angle between them | −3, ≈ 96.9° |
| gradient descent, η = 0.1 vs η = 0.3 | converges to w = 3 vs diverges to −41 |

## Key Learnings
1. Sample variance divides by n−1 because the mean was estimated from the same data - one
   degree of freedom is already spent.
2. Precision and recall are two *different* conditional probabilities over the same table.
   Which one matters depends on which error is more expensive.
3. A 99%-sensitive test on a 1%-prevalence disease is right only 17% of the time when it
   fires. This is the same arithmetic that makes high accuracy on imbalanced data meaningless.
4. A neuron *is* a dot product: `w · x + b`. Cosine similarity is that same quantity
   normalised - which is how Week 4's vector store will rank retrieved chunks.
5. Running gradient descent by hand made the learning rate concrete: at η = 0.3 the error
   flips sign and grows, which is exactly what a loss going to NaN looks like.

## Submission Status
**Status:** Completed
**Submitted On:** _<fill in>_
